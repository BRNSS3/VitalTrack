"use client";
import { useAppData } from "@/lib/storage";
import { useMemo, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";
import { ChevronLeft, ChevronRight } from "lucide-react";

const MOOD_COLORS: Record<number, string> = {
  1: "#FF6B6B", 2: "#FFB347", 3: "#94A3B8", 4: "#00E5A0", 5: "#7C6AF7",
};
const MOOD_EMOJI: Record<number, string> = {
  1: "😞", 2: "😕", 3: "😐", 4: "😊", 5: "😄",
};

export default function HealthCalendar() {
  const { data } = useAppData();
  const today = new Date();
  const [viewDate, setViewDate] = useState(new Date(today.getFullYear(), today.getMonth(), 1));

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const monthLabel = viewDate.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

  // Build calendar grid
  const firstDay = new Date(year, month, 1).getDay(); // 0=Sun
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = Array.from({ length: firstDay }, () => null).concat(
    Array.from({ length: daysInMonth }, (_, i) => i + 1)
  );

  function dateStr(day: number) {
    return `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  }

  function getEntry(day: number) {
    return data.healthEntries.find((h) => h.date === dateStr(day));
  }

  const todayStr = today.toISOString().split("T")[0];

  // IMC + weight history for chart
  const heightM = (data.profile?.height ?? 172) / 100;
  const weightHistory = useMemo(() =>
    data.healthEntries
      .filter((h) => h.weight !== undefined)
      .sort((a, b) => a.date > b.date ? 1 : -1)
      .slice(-30)
      .map((h) => ({
        date: h.date.slice(5),
        peso: h.weight,
        imc: parseFloat((h.weight! / (heightM * heightM)).toFixed(1)),
      })),
    [data.healthEntries, heightM]
  );

  const bmiZones = [
    { y: 18.5, label: "Abaixo", color: "#FFB347" },
    { y: 25, label: "Normal", color: "#00E5A0" },
    { y: 30, label: "Sobrepeso", color: "#FFB347" },
  ];

  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const selectedEntry = selectedDay ? getEntry(selectedDay) : null;

  return (
    <div className="flex flex-col gap-4 pb-4">
      {/* Calendar */}
      <div className="rounded-2xl p-4" style={{ background: "var(--vt-card)", border: "1px solid var(--vt-border)" }}>
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => setViewDate(new Date(year, month - 1, 1))}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:opacity-70 transition-all"
            style={{ background: "var(--vt-input)" }}>
            <ChevronLeft size={16} style={{ color: "var(--vt-text)" }} />
          </button>
          <h3 className="text-sm font-semibold capitalize" style={{ color: "var(--vt-text)" }}>{monthLabel}</h3>
          <button onClick={() => setViewDate(new Date(year, month + 1, 1))}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:opacity-70 transition-all"
            style={{ background: "var(--vt-input)" }}>
            <ChevronRight size={16} style={{ color: "var(--vt-text)" }} />
          </button>
        </div>

        {/* Day headers */}
        <div className="grid grid-cols-7 mb-2">
          {["D","S","T","Q","Q","S","S"].map((d, i) => (
            <div key={i} className="text-center text-[10px] font-medium" style={{ color: "var(--vt-muted)" }}>{d}</div>
          ))}
        </div>

        {/* Day cells */}
        <div className="grid grid-cols-7 gap-1">
          {cells.map((day, i) => {
            if (!day) return <div key={i} />;
            const entry = getEntry(day);
            const ds = dateStr(day);
            const isToday = ds === todayStr;
            const isFuture = ds > todayStr;
            const isSelected = selectedDay === day;
            const mood = entry?.mood;
            const hasData = !!entry;

            return (
              <button
                key={i}
                onClick={() => setSelectedDay(isSelected ? null : day)}
                disabled={isFuture}
                className="aspect-square rounded-lg flex items-center justify-center relative transition-all active:scale-90"
                style={{
                  background: isSelected
                    ? "var(--vt-finance)"
                    : mood
                    ? `${MOOD_COLORS[mood]}25`
                    : isToday
                    ? "var(--vt-input)"
                    : "transparent",
                  border: isToday ? "1px solid var(--vt-finance)" : "1px solid transparent",
                  opacity: isFuture ? 0.3 : 1,
                }}
              >
                {mood ? (
                  <span className="text-sm leading-none">{MOOD_EMOJI[mood]}</span>
                ) : (
                  <span className="text-xs font-medium" style={{
                    color: isSelected ? "#fff" : isToday ? "var(--vt-finance)" : "var(--vt-text)"
                  }}>
                    {day}
                  </span>
                )}
                {hasData && !mood && (
                  <div className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full" style={{ background: "var(--vt-health)" }} />
                )}
              </button>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-3 mt-3 pt-3" style={{ borderTop: "1px solid var(--vt-border)" }}>
          {Object.entries(MOOD_EMOJI).map(([k, emoji]) => (
            <div key={k} className="flex items-center gap-1">
              <span className="text-xs">{emoji}</span>
              <span className="text-[10px]" style={{ color: "var(--vt-muted)" }}>
                {["Péssimo","Ruim","Ok","Bem","Ótimo"][parseInt(k)-1]}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Selected day detail */}
      {selectedDay && (
        <div className="rounded-2xl p-4" style={{ background: "var(--vt-card)", border: "1px solid var(--vt-border)" }}>
          <h3 className="text-sm font-semibold mb-3" style={{ color: "var(--vt-text)" }}>
            {String(selectedDay).padStart(2,"0")}/{String(month+1).padStart(2,"0")}/{year}
          </h3>
          {selectedEntry ? (
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "⚖️ Peso", value: selectedEntry.weight ? `${selectedEntry.weight}kg` : "—" },
                { label: "👟 Passos", value: selectedEntry.steps ? selectedEntry.steps.toLocaleString("pt-BR") : "—" },
                { label: "💧 Água", value: selectedEntry.water ? `${selectedEntry.water} copos` : "—" },
                { label: "🌙 Sono", value: selectedEntry.sleep ? `${selectedEntry.sleep}h` : "—" },
              ].map((item) => (
                <div key={item.label} className="rounded-xl p-2.5" style={{ background: "var(--vt-input)" }}>
                  <p className="text-[10px] mb-1" style={{ color: "var(--vt-muted)" }}>{item.label}</p>
                  <p className="text-sm font-bold" style={{ color: "var(--vt-text)" }}>{item.value}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-center py-4" style={{ color: "var(--vt-muted)" }}>Nenhum dado registrado neste dia</p>
          )}
        </div>
      )}

      {/* Weight + BMI chart */}
      {weightHistory.length > 1 && (
        <div className="rounded-2xl p-4" style={{ background: "var(--vt-card)", border: "1px solid var(--vt-border)" }}>
          <h3 className="text-xs font-semibold uppercase tracking-wide mb-3" style={{ color: "var(--vt-muted)" }}>
            Peso & IMC — últimos 30 dias
          </h3>
          <ResponsiveContainer width="100%" height={160}>
            <LineChart data={weightHistory} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
              <XAxis dataKey="date" tick={{ fill: "var(--vt-muted)", fontSize: 9 }} axisLine={false} tickLine={false} interval={4} />
              <YAxis yAxisId="peso" domain={["auto","auto"]} tick={{ fill: "var(--vt-muted)", fontSize: 9 }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="imc" orientation="right" domain={[15, 35]} tick={{ fill: "var(--vt-muted)", fontSize: 9 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "var(--vt-card)", border: "1px solid var(--vt-border)", borderRadius: 8, color: "var(--vt-text)", fontSize: 11 }} />
              <ReferenceLine yAxisId="imc" y={18.5} stroke="#FFB34740" strokeDasharray="4 2" />
              <ReferenceLine yAxisId="imc" y={25} stroke="#00E5A040" strokeDasharray="4 2" />
              <ReferenceLine yAxisId="imc" y={30} stroke="#FF6B6B40" strokeDasharray="4 2" />
              <Line yAxisId="peso" type="monotone" dataKey="peso" stroke="var(--vt-health)" strokeWidth={2} dot={false} name="Peso (kg)" />
              <Line yAxisId="imc" type="monotone" dataKey="imc" stroke="var(--vt-finance)" strokeWidth={1.5} dot={false} strokeDasharray="5 3" name="IMC" />
            </LineChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-2">
            <div className="flex items-center gap-1.5">
              <div className="w-4 h-0.5 rounded" style={{ background: "var(--vt-health)" }} />
              <span className="text-[10px]" style={{ color: "var(--vt-muted)" }}>Peso</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-4 border-t border-dashed" style={{ borderColor: "var(--vt-finance)" }} />
              <span className="text-[10px]" style={{ color: "var(--vt-muted)" }}>IMC</span>
            </div>
          </div>
          {/* IMC zones legend */}
          <div className="flex gap-3 mt-2 flex-wrap">
            {[
              { label: "< 18.5 Abaixo", color: "#FFB347" },
              { label: "18.5–25 Normal", color: "#00E5A0" },
              { label: "25–30 Sobrepeso", color: "#FFB347" },
              { label: "> 30 Obeso", color: "#FF6B6B" },
            ].map((z) => (
              <div key={z.label} className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-full" style={{ background: z.color }} />
                <span className="text-[9px]" style={{ color: "var(--vt-muted)" }}>{z.label}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
