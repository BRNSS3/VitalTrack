"use client";
import { useState } from "react";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell,
} from "recharts";
import {
  useAppData,
  MOOD_LABELS,
  type HealthEntry,
} from "@/lib/storage";
import {
  Activity, Droplets, Heart, Moon, Plus, Scale, Smile, X, Flame, Settings,
} from "lucide-react";

// ─── ProfileModal ─────────────────────────────────────────────────────────────
function ProfileModal({ onClose, height, onSave }: { onClose: () => void; height: number; onSave: (h: number) => void }) {
  const [val, setVal] = useState(height.toString());
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md rounded-t-2xl bg-[#161A23] border border-[#252A36] flex flex-col max-h-[92vh]" onClick={(e) => e.stopPropagation()}>
        <div className="overflow-y-auto px-5 pt-5 pb-2 flex-1">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold text-[#F0F2F7]">Meu Perfil</h3>
            <button onClick={onClose} className="text-[#6B7280] hover:text-white"><X size={20} /></button>
          </div>
          <label className="text-xs text-[#6B7280] mb-1 block">Sua altura (cm)</label>
          <input
            type="number"
            value={val}
            onChange={(e) => setVal(e.target.value)}
            className="w-full bg-[#1E2433] border border-[#252A36] rounded-xl px-4 py-3 text-[#F0F2F7] text-sm focus:outline-none focus:border-[#00E5A0]"
          />
        </div>
        <div className="px-5 pt-3 pb-8 border-t border-[#252A36] bg-[#161A23]">
          <button
            onClick={() => { onSave(parseFloat(val) || 172); onClose(); }}
            className="w-full py-4 rounded-2xl bg-[#00E5A0] text-[#0D0F14] font-bold text-base active:scale-95 transition-all"
          >
            Salvar
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── MetricCard ───────────────────────────────────────────────────────────────
function MetricCard({ icon, label, value, unit, color, max, current, onAdd, streak }: {
  icon: React.ReactNode; label: string; value: string | number; unit: string; color: string;
  max?: number; current?: number; onAdd?: () => void; streak?: number;
}) {
  const pct = max && current !== undefined ? Math.min((current / max) * 100, 100) : null;
  return (
    <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: `${color}18` }}>
            <span style={{ color }}>{icon}</span>
          </div>
          <span className="text-xs text-[#6B7280] font-medium">{label}</span>
        </div>
        <div className="flex items-center gap-1.5">
          {streak !== undefined && streak > 0 && (
            <span className="text-xs text-[#FFB347] flex items-center gap-0.5">
              <Flame size={11} />
              {streak}
            </span>
          )}
          {onAdd && (
            <button onClick={onAdd} className="w-6 h-6 rounded-full bg-[#252A36] flex items-center justify-center hover:bg-[#2D3444] transition-colors">
              <Plus size={12} className="text-[#9CA3AF]" />
            </button>
          )}
        </div>
      </div>
      <div className="flex items-end gap-1">
        <span className="text-2xl font-bold text-[#F0F2F7]">{value}</span>
        <span className="text-sm text-[#6B7280] mb-0.5">{unit}</span>
      </div>
      {pct !== null && (
        <div className="h-1.5 rounded-full bg-[#252A36] overflow-hidden">
          <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: color }} />
        </div>
      )}
    </div>
  );
}

// ─── AddHealthModal ───────────────────────────────────────────────────────────
interface AddHealthModalProps {
  onClose: () => void;
  onSave: (entry: Omit<HealthEntry, "id" | "createdAt">) => void;
  todayEntry?: Partial<HealthEntry>;
}

function AddHealthModal({ onClose, onSave, todayEntry }: AddHealthModalProps) {
  const today = new Date().toISOString().split("T")[0];
  const [weight, setWeight] = useState(todayEntry?.weight?.toString() ?? "");
  const [steps, setSteps] = useState(todayEntry?.steps?.toString() ?? "");
  const [water, setWater] = useState(todayEntry?.water?.toString() ?? "");
  const [sleep, setSleep] = useState(todayEntry?.sleep?.toString() ?? "");
  const [mood, setMood] = useState<number>(todayEntry?.mood ?? 3);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md rounded-t-2xl bg-[#161A23] border border-[#252A36] flex flex-col max-h-[92vh]" onClick={(e) => e.stopPropagation()}>
        <div className="overflow-y-auto px-5 pt-5 pb-2 flex-1">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold text-[#F0F2F7] text-base">Registrar Saúde — Hoje</h3>
            <button onClick={onClose} className="text-[#6B7280] hover:text-white"><X size={20} /></button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Peso (kg)", val: weight, set: setWeight, ph: "75.0" },
              { label: "Passos", val: steps, set: setSteps, ph: "8000" },
              { label: "Copos de água", val: water, set: setWater, ph: "8" },
              { label: "Sono (horas)", val: sleep, set: setSleep, ph: "8" },
            ].map((f) => (
              <div key={f.label}>
                <label className="text-xs text-[#6B7280] mb-1 block">{f.label}</label>
                <input type="number" placeholder={f.ph} value={f.val} onChange={(e) => f.set(e.target.value)}
                  className="w-full bg-[#1E2433] border border-[#252A36] rounded-xl px-4 py-3 text-[#F0F2F7] text-sm placeholder:text-[#4B5563] focus:outline-none focus:border-[#00E5A0] transition-colors" />
              </div>
            ))}
          </div>
          <div className="mt-3">
            <label className="text-xs text-[#6B7280] mb-2 block">Humor</label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((m) => (
                <button key={m} onClick={() => setMood(m)}
                  className={`flex-1 py-2 rounded-xl text-base transition-all ${mood === m ? "bg-[#00E5A0]/20 border border-[#00E5A0]" : "bg-[#252A36] border border-transparent"}`}>
                  {["😞", "😕", "😐", "😊", "😄"][m - 1]}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="px-5 pt-3 pb-8 border-t border-[#252A36] bg-[#161A23]">
          <button
            onClick={() => {
              onSave({ date: today, weight: weight ? parseFloat(weight) : undefined, steps: steps ? parseInt(steps) : undefined, water: water ? parseInt(water) : undefined, sleep: sleep ? parseFloat(sleep) : undefined, mood: mood as 1 | 2 | 3 | 4 | 5 });
              onClose();
            }}
            className="w-full py-4 rounded-2xl bg-[#00E5A0] text-[#0D0F14] font-bold text-base hover:bg-[#00CCB1] active:scale-95 transition-all"
          >
            Salvar
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── HealthDashboard ──────────────────────────────────────────────────────────
export default function HealthDashboard() {
  const { data, upsertHealthEntry, updateProfile, todayHealth, latestWeight, streaks } = useAppData();
  const [showModal, setShowModal] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  const heightM = (data.profile?.height ?? 172) / 100;
  const bmi = latestWeight ? latestWeight / (heightM * heightM) : null;
  const bmiLabel = bmi ? bmi < 18.5 ? "Abaixo" : bmi < 25 ? "Normal" : bmi < 30 ? "Sobrepeso" : "Obeso" : "-";
  const bmiColor = bmi ? bmi < 18.5 ? "#FFB347" : bmi < 25 ? "#00E5A0" : bmi < 30 ? "#FFB347" : "#FF6B6B" : "#6B7280";

  // Last 7 days for charts
  const last7 = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() - (6 - i) * 86400000);
    const dateStr = d.toISOString().split("T")[0];
    const label = d.toLocaleDateString("pt-BR", { weekday: "short" }).replace(".", "");
    const entry = data.healthEntries.find((h) => h.date === dateStr);
    return {
      label,
      weight: entry?.weight,
      sleep: entry?.sleep,
      mood: entry?.mood,
      water: entry?.water,
      steps: entry?.steps,
    };
  });

  const weightHistory = data.healthEntries
    .filter((h) => h.weight !== undefined)
    .sort((a, b) => a.date > b.date ? 1 : -1)
    .slice(-14)
    .map((h) => ({ date: h.date.slice(5), weight: h.weight }));

  const moodColors: Record<number, string> = { 1: "#FF6B6B", 2: "#FFB347", 3: "#F0F2F7", 4: "#00E5A0", 5: "#7C6AF7" };

  function quickAddWater() {
    upsertHealthEntry({ date: new Date().toISOString().split("T")[0], water: (todayHealth?.water ?? 0) + 1 });
  }
  function quickAddSteps() {
    upsertHealthEntry({ date: new Date().toISOString().split("T")[0], steps: (todayHealth?.steps ?? 0) + 1000 });
  }

  const mood = todayHealth?.mood;
  const moodEmoji = mood ? ["😞", "😕", "😐", "😊", "😄"][mood - 1] : "—";

  return (
    <div className="flex flex-col gap-4 pb-4">
      {/* Profile button */}
      <div className="flex justify-end">
        <button
          onClick={() => setShowProfile(true)}
          className="flex items-center gap-1.5 text-xs text-[#6B7280] hover:text-[#F0F2F7] transition-colors"
        >
          <Settings size={12} />
          Altura: {data.profile?.height ?? 172}cm
        </button>
      </div>

      {/* Streaks */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "Hidratação", streak: streaks.water, goal: "≥6 copos", color: "#38BDF8" },
          { label: "Passos", streak: streaks.steps, goal: "≥5.000", color: "#7C6AF7" },
          { label: "Sono", streak: streaks.sleep, goal: "≥7h", color: "#F472B6" },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl bg-[#161A23] border border-[#252A36] p-3 text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Flame size={14} style={{ color: s.streak > 0 ? "#FFB347" : "#4B5563" }} />
              <span className="text-lg font-bold" style={{ color: s.streak > 0 ? "#FFB347" : "#4B5563" }}>
                {s.streak}
              </span>
            </div>
            <p className="text-[10px] text-[#6B7280] font-medium">{s.label}</p>
            <p className="text-[9px] text-[#4B5563]">{s.goal}</p>
          </div>
        ))}
      </div>

      {/* Metrics grid */}
      <div className="grid grid-cols-2 gap-3">
        <MetricCard icon={<Scale size={16} />} label="Peso" value={latestWeight?.toFixed(1) ?? "—"} unit="kg" color="#00E5A0" />
        <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-4 flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#00E5A0]/15">
              <Heart size={16} className="text-[#00E5A0]" />
            </div>
            <span className="text-xs text-[#6B7280] font-medium">IMC</span>
          </div>
          <div className="flex items-end gap-1">
            <span className="text-2xl font-bold" style={{ color: bmiColor }}>{bmi?.toFixed(1) ?? "—"}</span>
          </div>
          <span className="text-xs font-medium" style={{ color: bmiColor }}>{bmiLabel}</span>
        </div>
        <MetricCard icon={<Activity size={16} />} label="Passos hoje" value={(todayHealth?.steps ?? 0).toLocaleString("pt-BR")} unit="passos" color="#7C6AF7" max={10000} current={todayHealth?.steps} onAdd={quickAddSteps} streak={streaks.steps} />
        <MetricCard icon={<Droplets size={16} />} label="Água" value={todayHealth?.water ?? 0} unit="copos" color="#38BDF8" max={8} current={todayHealth?.water} onAdd={quickAddWater} streak={streaks.water} />
        <MetricCard icon={<Moon size={16} />} label="Sono" value={todayHealth?.sleep ?? "—"} unit="h" color="#F472B6" max={9} current={todayHealth?.sleep} streak={streaks.sleep} />
        <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-4 flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#FFB347]/15">
              <Smile size={16} className="text-[#FFB347]" />
            </div>
            <span className="text-xs text-[#6B7280] font-medium">Humor</span>
          </div>
          <span className="text-3xl">{moodEmoji}</span>
          <span className="text-xs text-[#6B7280]">{mood ? MOOD_LABELS[mood].split(" ")[1] : "Não registrado"}</span>
        </div>
      </div>

      {/* Weight chart */}
      {weightHistory.length > 1 && (
        <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-4">
          <h3 className="text-xs font-semibold text-[#9CA3AF] mb-3 uppercase tracking-wide">Evolução do Peso</h3>
          <ResponsiveContainer width="100%" height={120}>
            <LineChart data={weightHistory} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
              <XAxis dataKey="date" tick={{ fill: "#6B7280", fontSize: 9 }} axisLine={false} tickLine={false} />
              <YAxis domain={["auto", "auto"]} tick={{ fill: "#6B7280", fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "#1E2433", border: "1px solid #252A36", borderRadius: 8, color: "#F0F2F7", fontSize: 12 }} formatter={(v: number) => [`${v} kg`, "Peso"]} />
              <Line type="monotone" dataKey="weight" stroke="#00E5A0" strokeWidth={2} dot={{ r: 3, fill: "#00E5A0", strokeWidth: 0 }} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Sleep chart */}
      <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-4">
        <h3 className="text-xs font-semibold text-[#9CA3AF] mb-3 uppercase tracking-wide">Sono — últimos 7 dias</h3>
        <ResponsiveContainer width="100%" height={110}>
          <BarChart data={last7} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
            <XAxis dataKey="label" tick={{ fill: "#6B7280", fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis domain={[0, 10]} tick={{ fill: "#6B7280", fontSize: 10 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: "#1E2433", border: "1px solid #252A36", borderRadius: 8, color: "#F0F2F7", fontSize: 12 }} formatter={(v: number) => [`${v}h`, "Sono"]} />
            <Bar dataKey="sleep" radius={[4, 4, 0, 0]}>
              {last7.map((entry, i) => (
                <Cell key={i} fill={(entry.sleep ?? 0) >= 7 ? "#F472B6" : "#F472B630"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
        <p className="text-[10px] text-[#4B5563] text-right mt-1">Meta: 7h+ 😴</p>
      </div>

      {/* Mood chart */}
      <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-4">
        <h3 className="text-xs font-semibold text-[#9CA3AF] mb-3 uppercase tracking-wide">Humor — últimos 7 dias</h3>
        <div className="flex items-end justify-between gap-1 h-16">
          {last7.map((entry, i) => {
            const m = entry.mood ?? 0;
            const height = m ? `${m * 20}%` : "4px";
            const emoji = m ? ["😞", "😕", "😐", "😊", "😄"][m - 1] : "·";
            return (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <span className="text-xs">{emoji}</span>
                <div className="w-full rounded-t-lg transition-all" style={{ height, background: m ? moodColors[m] : "#252A36", minHeight: "4px" }} />
                <span className="text-[9px] text-[#4B5563]">{entry.label}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick actions */}
      <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-4">
        <h3 className="text-xs font-semibold text-[#9CA3AF] mb-3 uppercase tracking-wide">Ações Rápidas</h3>
        <div className="grid grid-cols-2 gap-2">
          <button onClick={quickAddWater} className="flex items-center gap-2 p-3 rounded-xl bg-[#38BDF8]/10 border border-[#38BDF8]/30 hover:bg-[#38BDF8]/20 transition-all active:scale-95">
            <Droplets size={16} className="text-[#38BDF8]" />
            <span className="text-sm text-[#38BDF8] font-medium">+ 1 copo</span>
          </button>
          <button onClick={quickAddSteps} className="flex items-center gap-2 p-3 rounded-xl bg-[#7C6AF7]/10 border border-[#7C6AF7]/30 hover:bg-[#7C6AF7]/20 transition-all active:scale-95">
            <Activity size={16} className="text-[#7C6AF7]" />
            <span className="text-sm text-[#7C6AF7] font-medium">+ 1.000 passos</span>
          </button>
        </div>
      </div>

      {/* FAB */}
      <button onClick={() => setShowModal(true)} className="fixed bottom-24 right-4 w-12 h-12 rounded-full bg-[#00E5A0] flex items-center justify-center shadow-lg shadow-[#00E5A0]/30 hover:bg-[#00CCB1] transition-all active:scale-95 z-40">
        <Plus size={22} className="text-[#0D0F14]" />
      </button>

      {showModal && <AddHealthModal onClose={() => setShowModal(false)} onSave={upsertHealthEntry} todayEntry={todayHealth ?? {}} />}
      {showProfile && <ProfileModal onClose={() => setShowProfile(false)} height={data.profile?.height ?? 172} onSave={(h) => updateProfile({ height: h })} />}
    </div>
  );
}
