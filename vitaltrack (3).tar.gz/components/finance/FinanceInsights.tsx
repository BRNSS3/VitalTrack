"use client";
import { useAppData, formatCurrency, CATEGORY_LABELS, EXPENSE_CATEGORIES, type TransactionCategory } from "@/lib/storage";
import { useMemo, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, Legend } from "recharts";
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle2 } from "lucide-react";

const MONTH_NAMES = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];
const COLORS = ["#7C6AF7","#00E5A0","#FFB347","#FF6B6B","#38BDF8","#F472B6"];

export default function FinanceInsights() {
  const { data } = useAppData();
  const [compareA, setCompareA] = useState(() => {
    const d = new Date(); d.setMonth(d.getMonth() - 1);
    return d.toISOString().slice(0, 7);
  });
  const [compareB, setCompareB] = useState(() => new Date().toISOString().slice(0, 7));

  // Available months
  const availableMonths = useMemo(() => {
    const months = new Set<string>();
    data.transactions.forEach((t) => months.add(t.date.slice(0, 7)));
    return Array.from(months).sort().reverse();
  }, [data.transactions]);

  // Monthly totals
  function getMonthlyData(month: string) {
    const income = data.transactions.filter((t) => t.type === "income" && t.date.startsWith(month)).reduce((s, t) => s + t.amount, 0);
    const expenses = data.transactions.filter((t) => t.type === "expense" && t.date.startsWith(month)).reduce((s, t) => s + t.amount, 0);
    const byCategory = EXPENSE_CATEGORIES.map((cat) => ({
      cat, label: CATEGORY_LABELS[cat],
      value: data.transactions.filter((t) => t.type === "expense" && t.category === cat && t.date.startsWith(month)).reduce((s, t) => s + t.amount, 0),
    })).filter((c) => c.value > 0);
    return { income, expenses, balance: income - expenses, byCategory };
  }

  const dataA = getMonthlyData(compareA);
  const dataB = getMonthlyData(compareB);

  // Comparison chart data
  const comparisonData = EXPENSE_CATEGORIES.map((cat) => {
    const aVal = data.transactions.filter((t) => t.type === "expense" && t.category === cat && t.date.startsWith(compareA)).reduce((s, t) => s + t.amount, 0);
    const bVal = data.transactions.filter((t) => t.type === "expense" && t.category === cat && t.date.startsWith(compareB)).reduce((s, t) => s + t.amount, 0);
    return { name: CATEGORY_LABELS[cat].slice(0, 6), [formatMonth(compareA)]: aVal, [formatMonth(compareB)]: bVal };
  }).filter((d) => d[formatMonth(compareA)] > 0 || d[formatMonth(compareB)] > 0);

  // Spending forecast for current month
  const currentMonth = new Date().toISOString().slice(0, 7);
  const today = new Date();
  const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  const daysPassed = today.getDate();
  const daysLeft = daysInMonth - daysPassed;
  const spentSoFar = data.transactions.filter((t) => t.type === "expense" && t.date.startsWith(currentMonth)).reduce((s, t) => s + t.amount, 0);
  const dailyAvg = daysPassed > 0 ? spentSoFar / daysPassed : 0;
  const projectedTotal = dailyAvg * daysInMonth;
  const totalBudget = data.budgets.filter((b) => b.month === currentMonth).reduce((s, b) => s + b.limit, 0);
  const projectionPct = totalBudget > 0 ? (projectedTotal / totalBudget) * 100 : 0;

  function formatMonth(m: string) {
    const [y, mo] = m.split("-");
    return `${MONTH_NAMES[parseInt(mo) - 1]}/${y.slice(2)}`;
  }

  return (
    <div className="flex flex-col gap-4 pb-4">
      {/* Forecast */}
      <div className="rounded-2xl p-4" style={{ background: "var(--vt-card)", border: "1px solid var(--vt-border)" }}>
        <h3 className="text-xs font-semibold uppercase tracking-wide mb-3" style={{ color: "var(--vt-muted)" }}>
          Previsão de Gastos — {formatMonth(currentMonth)}
        </h3>
        <div className="flex items-end justify-between mb-3">
          <div>
            <p className="text-xs" style={{ color: "var(--vt-muted)" }}>Gasto até hoje</p>
            <p className="text-xl font-bold" style={{ color: "var(--vt-text)" }}>{formatCurrency(spentSoFar)}</p>
          </div>
          <div className="text-right">
            <p className="text-xs" style={{ color: "var(--vt-muted)" }}>Projeção final</p>
            <p className="text-xl font-bold" style={{ color: projectedTotal > totalBudget && totalBudget > 0 ? "var(--vt-danger)" : "var(--vt-health)" }}>
              {formatCurrency(projectedTotal)}
            </p>
          </div>
        </div>
        {/* Progress bar */}
        <div className="h-3 rounded-full overflow-hidden mb-2" style={{ background: "var(--vt-border)" }}>
          {/* spent */}
          <div className="h-full rounded-full transition-all" style={{
            width: `${Math.min((spentSoFar / Math.max(projectedTotal, spentSoFar)) * 100, 100)}%`,
            background: "var(--vt-finance)",
          }} />
        </div>
        <div className="flex justify-between text-xs" style={{ color: "var(--vt-muted)" }}>
          <span>Dia {daysPassed}/{daysInMonth}</span>
          <span>{daysLeft} dias restantes</span>
        </div>
        {totalBudget > 0 && (
          <div className={`mt-3 flex items-center gap-2 p-2.5 rounded-xl ${projectedTotal > totalBudget ? "bg-red-500/10" : "bg-green-500/10"}`}>
            {projectedTotal > totalBudget
              ? <AlertTriangle size={14} style={{ color: "var(--vt-danger)" }} />
              : <CheckCircle2 size={14} style={{ color: "var(--vt-health)" }} />}
            <p className="text-xs font-medium" style={{ color: projectedTotal > totalBudget ? "var(--vt-danger)" : "var(--vt-health)" }}>
              {projectedTotal > totalBudget
                ? `Atenção: projeção ultrapassa o orçamento em ${formatCurrency(projectedTotal - totalBudget)}`
                : `Dentro do orçamento! Você tem ${formatCurrency(totalBudget - projectedTotal)} de folga`}
            </p>
          </div>
        )}
        <p className="text-[10px] mt-2" style={{ color: "var(--vt-muted)" }}>
          Baseado na média de {formatCurrency(dailyAvg)}/dia nos últimos {daysPassed} dias
        </p>
      </div>

      {/* Month comparison selector */}
      <div className="rounded-2xl p-4" style={{ background: "var(--vt-card)", border: "1px solid var(--vt-border)" }}>
        <h3 className="text-xs font-semibold uppercase tracking-wide mb-3" style={{ color: "var(--vt-muted)" }}>
          Comparar Meses
        </h3>
        <div className="flex gap-2 mb-4">
          <div className="flex-1">
            <label className="text-[10px] mb-1 block" style={{ color: "var(--vt-muted)" }}>Mês A</label>
            <select value={compareA} onChange={(e) => setCompareA(e.target.value)}
              className="w-full rounded-xl px-3 py-2 text-sm focus:outline-none"
              style={{ background: "var(--vt-input)", border: "1px solid var(--vt-border)", color: "var(--vt-text)" }}>
              {availableMonths.map((m) => <option key={m} value={m}>{formatMonth(m)}</option>)}
            </select>
          </div>
          <div className="flex-1">
            <label className="text-[10px] mb-1 block" style={{ color: "var(--vt-muted)" }}>Mês B</label>
            <select value={compareB} onChange={(e) => setCompareB(e.target.value)}
              className="w-full rounded-xl px-3 py-2 text-sm focus:outline-none"
              style={{ background: "var(--vt-input)", border: "1px solid var(--vt-border)", color: "var(--vt-text)" }}>
              {availableMonths.map((m) => <option key={m} value={m}>{formatMonth(m)}</option>)}
            </select>
          </div>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          {[{ label: formatMonth(compareA), d: dataA, color: "#7C6AF7" }, { label: formatMonth(compareB), d: dataB, color: "#00E5A0" }].map((item) => (
            <div key={item.label} className="rounded-xl p-3" style={{ background: "var(--vt-input)", border: `1px solid ${item.color}30` }}>
              <p className="text-xs font-semibold mb-2" style={{ color: item.color }}>{item.label}</p>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span style={{ color: "var(--vt-muted)" }}>Receitas</span>
                  <span style={{ color: "var(--vt-health)" }}>{formatCurrency(item.d.income)}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span style={{ color: "var(--vt-muted)" }}>Gastos</span>
                  <span style={{ color: "var(--vt-danger)" }}>{formatCurrency(item.d.expenses)}</span>
                </div>
                <div className="flex justify-between text-xs font-bold border-t pt-1" style={{ borderColor: "var(--vt-border)" }}>
                  <span style={{ color: "var(--vt-muted)" }}>Saldo</span>
                  <span style={{ color: item.d.balance >= 0 ? "var(--vt-health)" : "var(--vt-danger)" }}>
                    {formatCurrency(item.d.balance)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Diff */}
        {dataA.expenses > 0 || dataB.expenses > 0 ? (
          <div className="rounded-xl p-3 mb-4" style={{ background: "var(--vt-input)" }}>
            <p className="text-xs font-semibold mb-1" style={{ color: "var(--vt-text)" }}>Diferença de gastos</p>
            <div className="flex items-center gap-2">
              {dataB.expenses <= dataA.expenses
                ? <TrendingDown size={16} style={{ color: "var(--vt-health)" }} />
                : <TrendingUp size={16} style={{ color: "var(--vt-danger)" }} />}
              <span className="text-sm font-bold" style={{ color: dataB.expenses <= dataA.expenses ? "var(--vt-health)" : "var(--vt-danger)" }}>
                {dataB.expenses <= dataA.expenses ? "▼" : "▲"} {formatCurrency(Math.abs(dataB.expenses - dataA.expenses))}
              </span>
              <span className="text-xs" style={{ color: "var(--vt-muted)" }}>
                {dataB.expenses <= dataA.expenses ? "menos" : "mais"} em {formatMonth(compareB)}
              </span>
            </div>
          </div>
        ) : null}

        {/* Category comparison bar chart */}
        {comparisonData.length > 0 && (
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={comparisonData} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
              <XAxis dataKey="name" tick={{ fill: "var(--vt-muted)", fontSize: 9 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "var(--vt-muted)", fontSize: 9 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "var(--vt-card)", border: "1px solid var(--vt-border)", borderRadius: 8, color: "var(--vt-text)", fontSize: 11 }} formatter={(v: number) => formatCurrency(v)} />
              <Bar dataKey={formatMonth(compareA)} fill="#7C6AF7" radius={[3, 3, 0, 0]} />
              <Bar dataKey={formatMonth(compareB)} fill="#00E5A0" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
