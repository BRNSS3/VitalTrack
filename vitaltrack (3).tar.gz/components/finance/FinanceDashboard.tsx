"use client";
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from "recharts";
import {
  useAppData, formatCurrency, formatDate, CATEGORY_LABELS, EXPENSE_CATEGORIES,
  type Transaction, type TransactionCategory, type TransactionType,
} from "@/lib/storage";
import { Plus, Trash2, TrendingDown, TrendingUp, X, RefreshCw, AlertTriangle, CheckCircle2, Edit2 } from "lucide-react";

const COLORS = ["#00E5A0", "#7C6AF7", "#FFB347", "#FF6B6B", "#38BDF8", "#F472B6", "#A3E635", "#FB923C"];

function CategoryBadge({ category }: { category: TransactionCategory }) {
  return (
    <span className="text-xs px-2 py-0.5 rounded-full bg-[#252A36] text-[#9CA3AF]">
      {CATEGORY_LABELS[category]}
    </span>
  );
}

// ─── AddTransactionModal ──────────────────────────────────────────────────────
interface AddTransactionModalProps {
  onClose: () => void;
  onAdd: (t: Omit<Transaction, "id" | "createdAt">) => void;
}

function AddTransactionModal({ onClose, onAdd }: AddTransactionModalProps) {
  const today = new Date().toISOString().split("T")[0];
  const [type, setType] = useState<TransactionType>("expense");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<TransactionCategory>("alimentacao");
  const [date, setDate] = useState(today);
  const [recurring, setRecurring] = useState(false);

  const cats = type === "expense" ? EXPENSE_CATEGORIES : ["salario", "freelance", "investimento", "outros"] as TransactionCategory[];

  function handleSubmit() {
    const amt = parseFloat(amount.replace(",", "."));
    if (!amt || !description.trim()) return;
    onAdd({ type, amount: amt, description: description.trim(), category, date, recurring });
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md rounded-t-2xl bg-[#161A23] border border-[#252A36] flex flex-col max-h-[92vh]" onClick={(e) => e.stopPropagation()}>
        {/* scrollable content */}
        <div className="overflow-y-auto px-5 pt-5 pb-2 flex-1">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold text-[#F0F2F7] text-base">Nova Transação</h3>
            <button onClick={onClose} className="text-[#6B7280] hover:text-white"><X size={20} /></button>
          </div>
          <div className="flex gap-2 mb-4">
            <button onClick={() => { setType("expense"); setCategory("alimentacao"); }}
              className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${type === "expense" ? "bg-[#FF6B6B]/20 border border-[#FF6B6B] text-[#FF6B6B]" : "bg-[#252A36] text-[#6B7280] border border-transparent"}`}>
              Gasto
            </button>
            <button onClick={() => { setType("income"); setCategory("salario"); }}
              className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${type === "income" ? "bg-[#00E5A0]/20 border border-[#00E5A0] text-[#00E5A0]" : "bg-[#252A36] text-[#6B7280] border border-transparent"}`}>
              Receita
            </button>
          </div>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-[#6B7280] mb-1 block">Valor (R$)</label>
              <input type="number" placeholder="0,00" value={amount} onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-[#1E2433] border border-[#252A36] rounded-xl px-4 py-3 text-[#F0F2F7] text-sm placeholder:text-[#4B5563] focus:outline-none focus:border-[#7C6AF7] transition-colors" />
            </div>
            <div>
              <label className="text-xs text-[#6B7280] mb-1 block">Descrição</label>
              <input type="text" placeholder="Ex: Almoço, Uber..." value={description} onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-[#1E2433] border border-[#252A36] rounded-xl px-4 py-3 text-[#F0F2F7] text-sm placeholder:text-[#4B5563] focus:outline-none focus:border-[#7C6AF7] transition-colors" />
            </div>
            <div>
              <label className="text-xs text-[#6B7280] mb-1 block">Categoria</label>
              <select value={category} onChange={(e) => setCategory(e.target.value as TransactionCategory)}
                className="w-full bg-[#1E2433] border border-[#252A36] rounded-xl px-4 py-3 text-[#F0F2F7] text-sm focus:outline-none focus:border-[#7C6AF7] transition-colors">
                {cats.map((c) => <option key={c} value={c}>{CATEGORY_LABELS[c]}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-[#6B7280] mb-1 block">Data</label>
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
                className="w-full bg-[#1E2433] border border-[#252A36] rounded-xl px-4 py-3 text-[#F0F2F7] text-sm focus:outline-none focus:border-[#7C6AF7] transition-colors" />
            </div>
            <button onClick={() => setRecurring(!recurring)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all ${recurring ? "bg-[#7C6AF7]/20 border border-[#7C6AF7] text-[#7C6AF7]" : "bg-[#252A36] text-[#6B7280] border border-transparent"}`}>
              <RefreshCw size={14} />
              Conta recorrente
            </button>
          </div>
        </div>
        {/* fixed save button */}
        <div className="px-5 pt-3 pb-8 border-t border-[#252A36] bg-[#161A23]">
          <button onClick={handleSubmit} className="w-full py-4 rounded-2xl bg-[#7C6AF7] text-white font-bold text-base hover:bg-[#6B59E6] transition-colors active:scale-95">
            Adicionar
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── EditBudgetModal ──────────────────────────────────────────────────────────
function EditBudgetModal({ onClose }: { onClose: () => void }) {
  const { data, upsertBudget, currentMonth } = useAppData();
  const [limits, setLimits] = useState<Record<string, string>>(() => {
    const m: Record<string, string> = {};
    EXPENSE_CATEGORIES.forEach((cat) => {
      const b = data.budgets.find((b) => b.category === cat && b.month === currentMonth);
      m[cat] = b ? b.limit.toString() : "";
    });
    return m;
  });

  function handleSave() {
    EXPENSE_CATEGORIES.forEach((cat) => {
      const val = parseFloat(limits[cat] ?? "");
      if (val > 0) upsertBudget({ category: cat, limit: val, month: currentMonth });
    });
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md rounded-t-2xl bg-[#161A23] border border-[#252A36] flex flex-col max-h-[92vh]" onClick={(e) => e.stopPropagation()}>
        <div className="overflow-y-auto px-5 pt-5 pb-2 flex-1">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold text-[#F0F2F7]">Limites de Orçamento</h3>
            <button onClick={onClose} className="text-[#6B7280] hover:text-white"><X size={20} /></button>
          </div>
          <div className="space-y-3">
            {EXPENSE_CATEGORIES.map((cat) => (
              <div key={cat} className="flex items-center gap-3">
                <span className="text-sm text-[#9CA3AF] flex-1">{CATEGORY_LABELS[cat]}</span>
                <input type="number" placeholder="Sem limite" value={limits[cat] ?? ""} onChange={(e) => setLimits({ ...limits, [cat]: e.target.value })}
                  className="w-28 bg-[#1E2433] border border-[#252A36] rounded-xl px-3 py-2 text-[#F0F2F7] text-sm text-right focus:outline-none focus:border-[#7C6AF7]" />
              </div>
            ))}
          </div>
        </div>
        <div className="px-5 pt-3 pb-8 border-t border-[#252A36] bg-[#161A23]">
          <button onClick={handleSave} className="w-full py-4 rounded-2xl bg-[#7C6AF7] text-white font-bold text-base active:scale-95 transition-all">
            Salvar Orçamentos
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── FinanceDashboard ─────────────────────────────────────────────────────────
export default function FinanceDashboard() {
  const { data, addTransaction, removeTransaction, updateTransaction, monthlyIncome, monthlyExpenses, balance, currentMonth, budgetStatus } = useAppData();
  const [showModal, setShowModal] = useState(false);
  const [showBudget, setShowBudget] = useState(false);
  const [filter, setFilter] = useState<"all" | "expense" | "income">("all");

  const expenseByCategory = EXPENSE_CATEGORIES.map((cat) => ({
    name: CATEGORY_LABELS[cat],
    value: data.transactions.filter((t) => t.type === "expense" && t.category === cat && t.date.startsWith(currentMonth)).reduce((s, t) => s + t.amount, 0),
  })).filter((d) => d.value > 0);

  const last7 = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() - (6 - i) * 86400000);
    const dateStr = d.toISOString().split("T")[0];
    const label = d.toLocaleDateString("pt-BR", { weekday: "short" }).replace(".", "");
    const expenses = data.transactions.filter((t) => t.type === "expense" && t.date === dateStr).reduce((s, t) => s + t.amount, 0);
    return { label, expenses };
  });

  const filtered = data.transactions.filter((t) => filter === "all" || t.type === filter).slice(0, 30);

  // Budget alerts
  const overBudget = budgetStatus.filter((b) => b.over);
  const nearBudget = budgetStatus.filter((b) => !b.over && b.pct >= 80);

  return (
    <div className="flex flex-col gap-4 pb-4">
      {/* Budget alerts */}
      {overBudget.length > 0 && (
        <div className="rounded-2xl bg-[#FF6B6B]/10 border border-[#FF6B6B]/40 p-3">
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle size={14} className="text-[#FF6B6B]" />
            <span className="text-xs font-semibold text-[#FF6B6B]">Limite ultrapassado!</span>
          </div>
          {overBudget.map((b) => (
            <p key={b.category} className="text-xs text-[#FF6B6B]/80 ml-5">
              {CATEGORY_LABELS[b.category]}: {formatCurrency(b.spent)} / {formatCurrency(b.limit)}
            </p>
          ))}
        </div>
      )}
      {nearBudget.length > 0 && overBudget.length === 0 && (
        <div className="rounded-2xl bg-[#FFB347]/10 border border-[#FFB347]/40 p-3">
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle size={14} className="text-[#FFB347]" />
            <span className="text-xs font-semibold text-[#FFB347]">Atenção ao orçamento</span>
          </div>
          {nearBudget.map((b) => (
            <p key={b.category} className="text-xs text-[#FFB347]/80 ml-5">
              {CATEGORY_LABELS[b.category]}: {b.pct.toFixed(0)}% usado
            </p>
          ))}
        </div>
      )}

      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-3 flex flex-col gap-1">
          <span className="text-[10px] text-[#6B7280] uppercase tracking-wide">Saldo</span>
          <span className={`text-sm font-bold ${balance >= 0 ? "text-[#00E5A0]" : "text-[#FF6B6B]"}`}>{formatCurrency(balance)}</span>
        </div>
        <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-3 flex flex-col gap-1">
          <span className="text-[10px] text-[#6B7280] uppercase tracking-wide">Receitas</span>
          <span className="text-sm font-bold text-[#00E5A0]">{formatCurrency(monthlyIncome)}</span>
        </div>
        <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-3 flex flex-col gap-1">
          <span className="text-[10px] text-[#6B7280] uppercase tracking-wide">Gastos</span>
          <span className="text-sm font-bold text-[#FF6B6B]">{formatCurrency(monthlyExpenses)}</span>
        </div>
      </div>

      {/* Bar chart */}
      <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-4">
        <h3 className="text-xs font-semibold text-[#9CA3AF] mb-3 uppercase tracking-wide">Gastos — últimos 7 dias</h3>
        <ResponsiveContainer width="100%" height={120}>
          <BarChart data={last7} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
            <XAxis dataKey="label" tick={{ fill: "#6B7280", fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "#6B7280", fontSize: 10 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: "#1E2433", border: "1px solid #252A36", borderRadius: 8, color: "#F0F2F7", fontSize: 12 }} formatter={(v: number) => [formatCurrency(v), "Gastos"]} />
            <Bar dataKey="expenses" radius={[4, 4, 0, 0]}>
              {last7.map((_, i) => <Cell key={i} fill={i === 6 ? "#7C6AF7" : "#7C6AF740"} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Budget bars */}
      {budgetStatus.length > 0 && (
        <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wide">Orçamento do Mês</h3>
            <button onClick={() => setShowBudget(true)} className="text-xs text-[#7C6AF7] flex items-center gap-1 hover:opacity-80">
              <Edit2 size={11} /> Editar
            </button>
          </div>
          <div className="space-y-3">
            {budgetStatus.map((b) => (
              <div key={b.category}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-[#9CA3AF]">{CATEGORY_LABELS[b.category]}</span>
                  <span className={`text-xs font-semibold ${b.over ? "text-[#FF6B6B]" : b.pct >= 80 ? "text-[#FFB347]" : "text-[#6B7280]"}`}>
                    {formatCurrency(b.spent)} / {formatCurrency(b.limit)}
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-[#252A36] overflow-hidden">
                  <div className="h-full rounded-full transition-all" style={{
                    width: `${b.pct}%`,
                    background: b.over ? "#FF6B6B" : b.pct >= 80 ? "#FFB347" : "#00E5A0",
                  }} />
                </div>
              </div>
            ))}
          </div>
          <button onClick={() => setShowBudget(true)} className="mt-3 text-xs text-[#6B7280] hover:text-[#9CA3AF] transition-colors">
            + Definir novos limites
          </button>
        </div>
      )}
      {budgetStatus.length === 0 && (
        <button onClick={() => setShowBudget(true)}
          className="rounded-2xl bg-[#161A23] border border-dashed border-[#252A36] p-4 text-center text-xs text-[#6B7280] hover:border-[#7C6AF7] hover:text-[#7C6AF7] transition-all">
          + Definir limites de orçamento por categoria
        </button>
      )}

      {/* Pie chart */}
      {expenseByCategory.length > 0 && (
        <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-4">
          <h3 className="text-xs font-semibold text-[#9CA3AF] mb-3 uppercase tracking-wide">Gastos por Categoria</h3>
          <div className="flex items-center gap-4">
            <PieChart width={110} height={110}>
              <Pie data={expenseByCategory} cx={50} cy={50} innerRadius={28} outerRadius={50} dataKey="value" stroke="none">
                {expenseByCategory.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
            </PieChart>
            <div className="flex-1 space-y-1.5">
              {expenseByCategory.slice(0, 5).map((item, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                    <span className="text-xs text-[#9CA3AF] truncate max-w-[90px]">{item.name}</span>
                  </div>
                  <span className="text-xs font-semibold text-[#F0F2F7]">{formatCurrency(item.value)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Transactions list */}
      <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wide">Transações</h3>
          <div className="flex gap-1">
            {(["all", "expense", "income"] as const).map((f) => (
              <button key={f} onClick={() => setFilter(f)}
                className={`text-[10px] px-2.5 py-1 rounded-full transition-all ${filter === f
                  ? f === "expense" ? "bg-[#FF6B6B]/20 text-[#FF6B6B] border border-[#FF6B6B]"
                    : f === "income" ? "bg-[#00E5A0]/20 text-[#00E5A0] border border-[#00E5A0]"
                    : "bg-[#7C6AF7]/20 text-[#7C6AF7] border border-[#7C6AF7]"
                  : "bg-[#252A36] text-[#6B7280] border border-transparent"}`}>
                {f === "all" ? "Todos" : f === "expense" ? "Gastos" : "Receitas"}
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-2 max-h-72 overflow-y-auto">
          {filtered.length === 0 && <p className="text-center text-[#6B7280] text-sm py-6">Nenhuma transação ainda</p>}
          {filtered.map((t) => (
            <div key={t.id} className="flex items-center gap-3 p-3 rounded-xl bg-[#1E2433] border border-[#252A36]">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${t.type === "income" ? "bg-[#00E5A0]/15" : "bg-[#FF6B6B]/15"}`}>
                {t.type === "income" ? <TrendingUp size={14} className="text-[#00E5A0]" /> : <TrendingDown size={14} className="text-[#FF6B6B]" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-medium text-[#F0F2F7] truncate">{t.description}</p>
                  {t.recurring && <RefreshCw size={10} className="text-[#7C6AF7] flex-shrink-0" />}
                </div>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <CategoryBadge category={t.category} />
                  <span className="text-[10px] text-[#4B5563]">{formatDate(t.date)}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <span className={`text-sm font-bold ${t.type === "income" ? "text-[#00E5A0]" : "text-[#FF6B6B]"}`}>
                  {t.type === "income" ? "+" : "-"}{formatCurrency(t.amount)}
                </span>
                <button onClick={() => removeTransaction(t.id)} className="text-[#4B5563] hover:text-[#FF6B6B] transition-colors">
                  <Trash2 size={13} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* FABs */}
      <button onClick={() => setShowModal(true)} className="fixed bottom-24 right-4 w-12 h-12 rounded-full bg-[#7C6AF7] flex items-center justify-center shadow-lg shadow-[#7C6AF7]/30 hover:bg-[#6B59E6] transition-all active:scale-95 z-40">
        <Plus size={22} className="text-white" />
      </button>

      {showModal && <AddTransactionModal onClose={() => setShowModal(false)} onAdd={addTransaction} />}
      {showBudget && <EditBudgetModal onClose={() => setShowBudget(false)} />}
    </div>
  );
}
