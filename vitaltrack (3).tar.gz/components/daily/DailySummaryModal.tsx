"use client";
import { useState } from "react";
import { useAppData, formatCurrency, type HealthEntry } from "@/lib/storage";
import { X } from "lucide-react";

interface DailySummaryModalProps {
  onClose: () => void;
}

export default function DailySummaryModal({ onClose }: DailySummaryModalProps) {
  const { todayHealth, upsertHealthEntry } = useAppData();
  const today = new Date().toISOString().split("T")[0];

  const [weight, setWeight] = useState(todayHealth?.weight?.toString() ?? "");
  const [steps, setSteps] = useState(todayHealth?.steps?.toString() ?? "");
  const [water, setWater] = useState(todayHealth?.water?.toString() ?? "");
  const [sleep, setSleep] = useState(todayHealth?.sleep?.toString() ?? "");
  const [mood, setMood] = useState<number>(todayHealth?.mood ?? 3);
  const [saved, setSaved] = useState(false);

  function handleSave() {
    upsertHealthEntry({
      date: today,
      weight: weight ? parseFloat(weight.replace(",", ".")) : undefined,
      steps: steps ? parseInt(steps) : undefined,
      water: water ? parseInt(water) : undefined,
      sleep: sleep ? parseFloat(sleep.replace(",", ".")) : undefined,
      mood: mood as 1 | 2 | 3 | 4 | 5,
    });
    setSaved(true);
    setTimeout(onClose, 1200);
  }

  const fields = [
    { label: "⚖️ Peso (kg)", value: weight, set: setWeight, placeholder: "75.0", type: "decimal" },
    { label: "👟 Passos", value: steps, set: setSteps, placeholder: "8000", type: "number" },
    { label: "💧 Copos de água", value: water, set: setWater, placeholder: "8", type: "number" },
    { label: "🌙 Sono (horas)", value: sleep, set: setSleep, placeholder: "8", type: "decimal" },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-md rounded-t-2xl bg-[#161A23] border border-[#252A36] flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {saved ? (
          <div className="flex flex-col items-center justify-center py-12 gap-3">
            <div className="text-5xl animate-bounce">✅</div>
            <p className="text-[#00E5A0] font-semibold text-lg">Dia registrado!</p>
            <p className="text-[#6B7280] text-sm">Continue assim! 💪</p>
          </div>
        ) : (
          <>
            {/* scrollable content */}
            <div className="overflow-y-auto px-5 pt-5 pb-2 flex-1">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h3 className="font-bold text-[#F0F2F7] text-base">Como foi seu dia?</h3>
                  <p className="text-xs text-[#6B7280] mt-0.5">Registre tudo de uma vez</p>
                </div>
                <button onClick={onClose} className="text-[#6B7280] hover:text-white transition-colors">
                  <X size={20} />
                </button>
              </div>
              <div className="grid grid-cols-2 gap-3 mt-4">
                {fields.map((f) => (
                  <div key={f.label}>
                    <label className="text-xs text-[#6B7280] mb-1 block">{f.label}</label>
                    <input
                      type="number"
                      placeholder={f.placeholder}
                      value={f.value}
                      onChange={(e) => f.set(e.target.value)}
                      className="w-full bg-[#1E2433] border border-[#252A36] rounded-xl px-3 py-3 text-[#F0F2F7] text-sm placeholder:text-[#4B5563] focus:outline-none focus:border-[#00E5A0] transition-colors"
                    />
                  </div>
                ))}
              </div>
              <div className="mt-3">
                <label className="text-xs text-[#6B7280] mb-2 block">😊 Humor</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((m) => (
                    <button
                      key={m}
                      onClick={() => setMood(m)}
                      className={`flex-1 py-2.5 rounded-xl text-xl transition-all ${
                        mood === m
                          ? "bg-[#00E5A0]/20 border border-[#00E5A0] scale-110"
                          : "bg-[#252A36] border border-transparent"
                      }`}
                    >
                      {["😞", "😕", "😐", "😊", "😄"][m - 1]}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            {/* fixed save button */}
            <div className="px-5 pt-3 pb-8 border-t border-[#252A36] bg-[#161A23]">
              <button
                onClick={handleSave}
                className="w-full py-4 rounded-2xl bg-[#00E5A0] text-[#0D0F14] font-bold text-base hover:bg-[#00CCB1] active:scale-95 transition-all"
              >
                Salvar dia 🎯
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
