"use client";
import { useState, useEffect } from "react";
import { useAppData, type Goal, type GoalCategory, type GoalSubtask } from "@/lib/storage";
import { Plus, Target, Trash2, CheckCircle2, X, ChevronDown, ChevronUp } from "lucide-react";

// ─── Confetti ─────────────────────────────────────────────────────────────────
function Confetti({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 3000);
    return () => clearTimeout(t);
  }, [onDone]);

  const pieces = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    delay: `${Math.random() * 0.8}s`,
    color: ["#00E5A0", "#7C6AF7", "#FFB347", "#FF6B6B", "#38BDF8", "#F472B6"][i % 6],
    size: `${6 + Math.random() * 8}px`,
  }));

  return (
    <div className="fixed inset-0 z-[100] pointer-events-none overflow-hidden">
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="text-center bg-[#161A23]/95 border border-[#00E5A0]/40 rounded-2xl p-6 px-8 shadow-2xl">
          <div className="text-5xl mb-2">🎉</div>
          <p className="text-[#00E5A0] font-bold text-lg">Meta concluída!</p>
          <p className="text-[#6B7280] text-sm mt-1">Continue assim! Você consegue!</p>
        </div>
      </div>
      {pieces.map((p) => (
        <div
          key={p.id}
          className="absolute top-0 rounded-sm animate-bounce"
          style={{
            left: p.left,
            width: p.size,
            height: p.size,
            background: p.color,
            animationDelay: p.delay,
            animationDuration: `${0.4 + Math.random() * 0.4}s`,
            transform: `rotate(${Math.random() * 360}deg)`,
          }}
        />
      ))}
    </div>
  );
}

// ─── AddGoalModal ─────────────────────────────────────────────────────────────
interface AddGoalModalProps {
  onClose: () => void;
  onAdd: (g: Omit<Goal, "id" | "createdAt">) => void;
}

function AddGoalModal({ onClose, onAdd }: AddGoalModalProps) {
  const [category, setCategory] = useState<GoalCategory>("health");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [targetValue, setTargetValue] = useState("");
  const [currentValue, setCurrentValue] = useState("");
  const [unit, setUnit] = useState("");
  const [deadline, setDeadline] = useState("");

  function handleAdd() {
    const t = parseFloat(targetValue.replace(",", "."));
    const c = parseFloat(currentValue.replace(",", ".") || "0");
    if (!title.trim() || !t || !unit.trim()) return;
    onAdd({ category, title: title.trim(), description: description.trim() || undefined, targetValue: t, currentValue: c, unit: unit.trim(), deadline: deadline || undefined, status: "active", subtasks: [] });
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md rounded-t-2xl bg-[#161A23] border border-[#252A36] flex flex-col max-h-[92vh]" onClick={(e) => e.stopPropagation()}>
        <div className="overflow-y-auto px-5 pt-5 pb-2 flex-1">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold text-[#F0F2F7] text-base">Nova Meta</h3>
            <button onClick={onClose} className="text-[#6B7280] hover:text-white"><X size={20} /></button>
          </div>
          <div className="flex gap-2 mb-4">
            <button onClick={() => setCategory("health")}
              className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${category === "health" ? "bg-[#00E5A0]/20 border border-[#00E5A0] text-[#00E5A0]" : "bg-[#252A36] text-[#6B7280] border border-transparent"}`}>
              💪 Saúde
            </button>
            <button onClick={() => setCategory("finance")}
              className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${category === "finance" ? "bg-[#7C6AF7]/20 border border-[#7C6AF7] text-[#7C6AF7]" : "bg-[#252A36] text-[#6B7280] border border-transparent"}`}>
              💰 Finanças
            </button>
          </div>
          <div className="space-y-3">
            {[
              { label: "Título da Meta", val: title, set: setTitle, ph: "Ex: Perder 5kg..." },
              { label: "Descrição (opcional)", val: description, set: setDescription, ph: "Detalhes..." },
            ].map((f) => (
              <div key={f.label}>
                <label className="text-xs text-[#6B7280] mb-1 block">{f.label}</label>
                <input type="text" placeholder={f.ph} value={f.val} onChange={(e) => f.set(e.target.value)}
                  className="w-full bg-[#1E2433] border border-[#252A36] rounded-xl px-4 py-3 text-[#F0F2F7] text-sm placeholder:text-[#4B5563] focus:outline-none focus:border-[#7C6AF7] transition-colors" />
              </div>
            ))}
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: "Valor Alvo", val: targetValue, set: setTargetValue, ph: "100" },
                { label: "Unidade", val: unit, set: setUnit, ph: "kg, R$..." },
                { label: "Progresso Atual", val: currentValue, set: setCurrentValue, ph: "0" },
                { label: "Prazo", val: deadline, set: setDeadline, ph: "", type: "date" },
              ].map((f) => (
                <div key={f.label}>
                  <label className="text-xs text-[#6B7280] mb-1 block">{f.label}</label>
                  <input type={f.type ?? "number"} placeholder={f.ph} value={f.val} onChange={(e) => f.set(e.target.value)}
                    className="w-full bg-[#1E2433] border border-[#252A36] rounded-xl px-4 py-3 text-[#F0F2F7] text-sm placeholder:text-[#4B5563] focus:outline-none focus:border-[#7C6AF7] transition-colors" />
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="px-5 pt-3 pb-8 border-t border-[#252A36] bg-[#161A23]">
          <button onClick={handleAdd} className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#7C6AF7] to-[#00E5A0] text-white font-bold text-base hover:opacity-90 active:scale-95 transition-all">
            Criar Meta
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── GoalCard ─────────────────────────────────────────────────────────────────
function GoalCard({ goal, onUpdate, onRemove, onToggleSubtask, onAddSubtask, onCelebrate }: {
  goal: Goal;
  onUpdate: (id: string, u: Partial<Goal>) => void;
  onRemove: (id: string) => void;
  onToggleSubtask: (goalId: string, subtaskId: string) => void;
  onAddSubtask: (goalId: string, title: string) => void;
  onCelebrate: () => void;
}) {
  const pct = Math.min((goal.currentValue / goal.targetValue) * 100, 100);
  const isCompleted = goal.status === "completed" || pct >= 100;
  const color = goal.category === "health" ? "#00E5A0" : "#7C6AF7";
  const daysLeft = goal.deadline ? Math.ceil((new Date(goal.deadline).getTime() - Date.now()) / 86400000) : null;

  const [editing, setEditing] = useState(false);
  const [newCurrent, setNewCurrent] = useState(goal.currentValue.toString());
  const [showSubtasks, setShowSubtasks] = useState(false);
  const [newSubtask, setNewSubtask] = useState("");
  const [addingSubtask, setAddingSubtask] = useState(false);

  const subtasks = goal.subtasks ?? [];
  const completedSubtasks = subtasks.filter((s) => s.completed).length;

  function handleComplete() {
    const wasCompleted = isCompleted;
    onUpdate(goal.id, { status: isCompleted ? "active" : "completed" });
    if (!wasCompleted) onCelebrate();
  }

  function saveProgress() {
    const val = parseFloat(newCurrent.replace(",", "."));
    if (!isNaN(val)) {
      const wasCompleted = isCompleted;
      const nowCompleted = val >= goal.targetValue;
      onUpdate(goal.id, { currentValue: val, status: nowCompleted ? "completed" : "active" });
      if (!wasCompleted && nowCompleted) onCelebrate();
    }
    setEditing(false);
  }

  return (
    <div className={`rounded-2xl bg-[#161A23] border p-4 ${isCompleted ? "border-[#00E5A0]/30" : "border-[#252A36]"}`}>
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="flex items-start gap-2">
          <span className="text-base mt-0.5">{goal.category === "health" ? "💪" : "💰"}</span>
          <div>
            <h4 className={`text-sm font-semibold ${isCompleted ? "line-through text-[#6B7280]" : "text-[#F0F2F7]"}`}>{goal.title}</h4>
            {goal.description && <p className="text-xs text-[#6B7280] mt-0.5">{goal.description}</p>}
          </div>
        </div>
        <div className="flex gap-1 flex-shrink-0">
          <button onClick={handleComplete} className={`transition-colors ${isCompleted ? "text-[#00E5A0]" : "text-[#4B5563] hover:text-[#00E5A0]"}`}>
            <CheckCircle2 size={16} />
          </button>
          <button onClick={() => onRemove(goal.id)} className="text-[#4B5563] hover:text-[#FF6B6B] transition-colors">
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      {/* Progress */}
      <div className="mb-2">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-[#6B7280]">{goal.currentValue} / {goal.targetValue} {goal.unit}</span>
          <span className="text-xs font-semibold" style={{ color }}>{pct.toFixed(0)}%</span>
        </div>
        <div className="h-2 rounded-full bg-[#252A36] overflow-hidden">
          <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: isCompleted ? "#00E5A0" : color }} />
        </div>
      </div>

      {/* Update progress */}
      {!isCompleted && (
        <div className="flex items-center gap-2 mt-2">
          {editing ? (
            <>
              <input type="number" value={newCurrent} onChange={(e) => setNewCurrent(e.target.value)}
                className="flex-1 bg-[#1E2433] border border-[#252A36] rounded-lg px-3 py-1.5 text-sm text-[#F0F2F7] focus:outline-none focus:border-[#7C6AF7]" autoFocus />
              <button onClick={saveProgress} className="text-xs px-3 py-1.5 rounded-lg bg-[#7C6AF7] text-white font-medium">Salvar</button>
              <button onClick={() => setEditing(false)} className="text-xs px-3 py-1.5 rounded-lg bg-[#252A36] text-[#9CA3AF]">✕</button>
            </>
          ) : (
            <button onClick={() => setEditing(true)} className="text-xs text-[#9CA3AF] hover:text-[#F0F2F7] transition-colors">
              Atualizar progresso →
            </button>
          )}
        </div>
      )}

      {daysLeft !== null && !isCompleted && (
        <p className={`text-xs mt-1.5 ${daysLeft < 7 ? "text-[#FF6B6B]" : "text-[#4B5563]"}`}>
          {daysLeft > 0 ? `${daysLeft} dias restantes` : "Prazo encerrado"}
        </p>
      )}

      {/* Subtasks */}
      {subtasks.length > 0 && (
        <div className="mt-3 border-t border-[#252A36] pt-3">
          <button onClick={() => setShowSubtasks(!showSubtasks)} className="flex items-center justify-between w-full text-xs text-[#6B7280] hover:text-[#9CA3AF]">
            <span>Tarefas: {completedSubtasks}/{subtasks.length}</span>
            {showSubtasks ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          </button>
          {showSubtasks && (
            <div className="mt-2 space-y-2">
              {subtasks.map((s) => (
                <div key={s.id} className="flex items-center gap-2" onClick={() => onToggleSubtask(goal.id, s.id)}>
                  <div className={`w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 cursor-pointer transition-all ${s.completed ? "bg-[#00E5A0] border-[#00E5A0]" : "border-[#4B5563]"}`}>
                    {s.completed && <CheckCircle2 size={10} className="text-[#0D0F14]" />}
                  </div>
                  <span className={`text-xs cursor-pointer ${s.completed ? "line-through text-[#4B5563]" : "text-[#9CA3AF]"}`}>{s.title}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Add subtask */}
      <div className="mt-2">
        {addingSubtask ? (
          <div className="flex items-center gap-2">
            <input type="text" value={newSubtask} onChange={(e) => setNewSubtask(e.target.value)} placeholder="Nova tarefa..."
              className="flex-1 bg-[#1E2433] border border-[#252A36] rounded-lg px-3 py-1.5 text-xs text-[#F0F2F7] placeholder:text-[#4B5563] focus:outline-none focus:border-[#7C6AF7]"
              autoFocus
              onKeyDown={(e) => { if (e.key === "Enter" && newSubtask.trim()) { onAddSubtask(goal.id, newSubtask.trim()); setNewSubtask(""); setAddingSubtask(false); setShowSubtasks(true); } }}
            />
            <button onClick={() => { if (newSubtask.trim()) { onAddSubtask(goal.id, newSubtask.trim()); setNewSubtask(""); setAddingSubtask(false); setShowSubtasks(true); } }} className="text-xs px-2 py-1.5 rounded-lg bg-[#7C6AF7] text-white">+</button>
            <button onClick={() => setAddingSubtask(false)} className="text-xs text-[#6B7280]">✕</button>
          </div>
        ) : (
          <button onClick={() => setAddingSubtask(true)} className="text-[10px] text-[#4B5563] hover:text-[#6B7280] transition-colors mt-1">
            + adicionar tarefa
          </button>
        )}
      </div>
    </div>
  );
}

// ─── GoalsDashboard ───────────────────────────────────────────────────────────
export default function GoalsDashboard() {
  const { data, addGoal, updateGoal, removeGoal, toggleSubtask, addSubtask } = useAppData();
  const [showModal, setShowModal] = useState(false);
  const [filter, setFilter] = useState<"all" | "health" | "finance">("all");
  const [celebrating, setCelebrating] = useState(false);

  const goals = data.goals.filter((g) => filter === "all" || g.category === filter);
  const active = goals.filter((g) => g.status !== "completed" && g.currentValue / g.targetValue < 1);
  const completed = goals.filter((g) => g.status === "completed" || g.currentValue / g.targetValue >= 1);

  return (
    <div className="flex flex-col gap-4 pb-4">
      {celebrating && <Confetti onDone={() => setCelebrating(false)} />}

      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl bg-[#161A23] border border-[#252A36] p-3 text-center">
          <span className="text-lg font-bold text-[#F0F2F7]">{data.goals.length}</span>
          <p className="text-[10px] text-[#6B7280] mt-0.5">Total</p>
        </div>
        <div className="rounded-2xl bg-[#161A23] border border-[#00E5A0]/30 p-3 text-center">
          <span className="text-lg font-bold text-[#00E5A0]">{active.length}</span>
          <p className="text-[10px] text-[#6B7280] mt-0.5">Ativas</p>
        </div>
        <div className="rounded-2xl bg-[#161A23] border border-[#7C6AF7]/30 p-3 text-center">
          <span className="text-lg font-bold text-[#7C6AF7]">{completed.length}</span>
          <p className="text-[10px] text-[#6B7280] mt-0.5">Concluídas</p>
        </div>
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        {(["all", "health", "finance"] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            className={`flex-1 py-2 rounded-xl text-xs font-medium transition-all ${filter === f
              ? f === "health" ? "bg-[#00E5A0]/20 border border-[#00E5A0] text-[#00E5A0]"
                : f === "finance" ? "bg-[#7C6AF7]/20 border border-[#7C6AF7] text-[#7C6AF7]"
                : "bg-[#252A36] text-[#F0F2F7] border border-[#4B5563]"
              : "bg-[#161A23] text-[#6B7280] border border-[#252A36]"}`}>
            {f === "all" ? "Todas" : f === "health" ? "💪 Saúde" : "💰 Finanças"}
          </button>
        ))}
      </div>

      {active.length === 0 && completed.length === 0 && (
        <div className="flex flex-col items-center justify-center py-12 gap-3">
          <Target size={40} className="text-[#252A36]" />
          <p className="text-[#6B7280] text-sm">Nenhuma meta ainda</p>
          <button onClick={() => setShowModal(true)} className="text-sm text-[#7C6AF7] hover:text-[#9B8FF9]">
            Criar sua primeira meta →
          </button>
        </div>
      )}

      {active.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wide">Em Andamento</h3>
          {active.map((g) => (
            <GoalCard key={g.id} goal={g} onUpdate={updateGoal} onRemove={removeGoal}
              onToggleSubtask={toggleSubtask} onAddSubtask={addSubtask}
              onCelebrate={() => setCelebrating(true)} />
          ))}
        </div>
      )}

      {completed.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wide">Concluídas 🏆</h3>
          {completed.map((g) => (
            <GoalCard key={g.id} goal={g} onUpdate={updateGoal} onRemove={removeGoal}
              onToggleSubtask={toggleSubtask} onAddSubtask={addSubtask}
              onCelebrate={() => setCelebrating(true)} />
          ))}
        </div>
      )}

      <button onClick={() => setShowModal(true)} className="fixed bottom-24 right-4 w-12 h-12 rounded-full bg-gradient-to-br from-[#7C6AF7] to-[#00E5A0] flex items-center justify-center shadow-lg hover:opacity-90 transition-all active:scale-95 z-40">
        <Plus size={22} className="text-white" />
      </button>

      {showModal && <AddGoalModal onClose={() => setShowModal(false)} onAdd={addGoal} />}
    </div>
  );
}
