"use client";
import { useAppData } from "@/lib/storage";
import { useTheme, THEMES, type ThemeMode } from "@/lib/theme";
import { useState, useRef } from "react";
import { Download, Upload, Trash2, CheckCircle2, X, Palette } from "lucide-react";

// ─── Theme Picker ─────────────────────────────────────────────────────────────
export function ThemePicker() {
  const { theme, setTheme } = useTheme();
  return (
    <div className="rounded-2xl p-4" style={{ background: "var(--vt-card)", border: "1px solid var(--vt-border)" }}>
      <div className="flex items-center gap-2 mb-4">
        <Palette size={14} style={{ color: "var(--vt-muted)" }} />
        <h3 className="text-xs font-semibold uppercase tracking-wide" style={{ color: "var(--vt-muted)" }}>Tema</h3>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {(Object.entries(THEMES) as [ThemeMode, typeof THEMES[ThemeMode]][]).map(([key, t]) => (
          <button
            key={key}
            onClick={() => setTheme(key)}
            className="rounded-2xl p-3 flex flex-col items-center gap-2 transition-all active:scale-95"
            style={{
              background: t.bg,
              border: `2px solid ${theme === key ? t.health : t.border}`,
              boxShadow: theme === key ? `0 0 12px ${t.health}40` : "none",
            }}
          >
            <span className="text-2xl">{t.emoji}</span>
            <div className="flex gap-1">
              <div className="w-3 h-3 rounded-full" style={{ background: t.health }} />
              <div className="w-3 h-3 rounded-full" style={{ background: t.finance }} />
            </div>
            <span className="text-[10px] font-semibold" style={{ color: t.text }}>{t.label}</span>
            {theme === key && (
              <div className="w-4 h-4 rounded-full flex items-center justify-center" style={{ background: t.health }}>
                <CheckCircle2 size={10} style={{ color: t.bg }} />
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Backup & Restore ─────────────────────────────────────────────────────────
export function BackupRestore() {
  const { data, save } = useAppData();
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [msg, setMsg] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  function handleExport() {
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `vitaltrack_backup_${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setStatus("success");
    setMsg("Backup exportado com sucesso!");
    setTimeout(() => setStatus("idle"), 3000);
  }

  function handleImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target?.result as string);
        if (!parsed.transactions || !parsed.healthEntries || !parsed.goals) throw new Error("Formato inválido");
        save({ ...parsed, profile: parsed.profile ?? { height: 172, name: "Você" } });
        setStatus("success");
        setMsg("Dados restaurados com sucesso!");
        setTimeout(() => setStatus("idle"), 3000);
      } catch {
        setStatus("error");
        setMsg("Arquivo inválido. Selecione um backup do VitalTrack.");
        setTimeout(() => setStatus("idle"), 3000);
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  }

  const stats = [
    { label: "Transações", value: data.transactions.length },
    { label: "Registros de saúde", value: data.healthEntries.length },
    { label: "Metas", value: data.goals.length },
  ];

  return (
    <div className="rounded-2xl p-4" style={{ background: "var(--vt-card)", border: "1px solid var(--vt-border)" }}>
      <div className="flex items-center gap-2 mb-4">
        <Download size={14} style={{ color: "var(--vt-muted)" }} />
        <h3 className="text-xs font-semibold uppercase tracking-wide" style={{ color: "var(--vt-muted)" }}>Backup & Restauração</h3>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl p-2.5 text-center" style={{ background: "var(--vt-input)" }}>
            <p className="text-lg font-bold" style={{ color: "var(--vt-text)" }}>{s.value}</p>
            <p className="text-[9px] leading-tight mt-0.5" style={{ color: "var(--vt-muted)" }}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* Status message */}
      {status !== "idle" && (
        <div className="rounded-xl p-3 mb-3 flex items-center gap-2"
          style={{ background: status === "success" ? "rgba(0,229,160,0.1)" : "rgba(255,107,107,0.1)", border: `1px solid ${status === "success" ? "var(--vt-health)" : "var(--vt-danger)"}30` }}>
          {status === "success"
            ? <CheckCircle2 size={14} style={{ color: "var(--vt-health)" }} />
            : <X size={14} style={{ color: "var(--vt-danger)" }} />}
          <p className="text-xs font-medium" style={{ color: status === "success" ? "var(--vt-health)" : "var(--vt-danger)" }}>{msg}</p>
        </div>
      )}

      {/* Buttons */}
      <div className="space-y-2">
        <button onClick={handleExport}
          className="w-full py-3.5 rounded-xl flex items-center justify-center gap-2 font-semibold text-sm transition-all active:scale-95"
          style={{ background: "var(--vt-health)", color: "var(--vt-bg)" }}>
          <Download size={16} />
          Exportar Backup (.json)
        </button>
        <button onClick={() => fileRef.current?.click()}
          className="w-full py-3.5 rounded-xl flex items-center justify-center gap-2 font-semibold text-sm transition-all active:scale-95"
          style={{ background: "var(--vt-input)", border: "1px solid var(--vt-border)", color: "var(--vt-text)" }}>
          <Upload size={16} />
          Restaurar Backup
        </button>
        <input ref={fileRef} type="file" accept=".json" onChange={handleImport} className="hidden" />
        <p className="text-[10px] text-center pt-1" style={{ color: "var(--vt-muted)" }}>
          💡 Exporte para transferir seus dados para outro dispositivo
        </p>
      </div>
    </div>
  );
}
