# VitalTrack
- One-line positioning: App mobile-friendly que unifica saúde e finanças em um painel sofisticado
- Target users: Pessoas que querem centralizar metas de saúde e controle financeiro no celular
- Core features:
  1. Dashboard principal com resumo de saúde + finanças
  2. Módulo financeiro: registrar despesas, orçamento mensal, metas financeiras
  3. Módulo saúde: peso/IMC, atividade física, hidratação, sono e humor
  4. Visualização de progresso com gráficos (recharts)
  5. Definição e acompanhamento de metas (saúde + financeiras)
- Device strategy: mobile_only
- Design style: escuro e sofisticado, glassmorphism, tema dark premium
- Technical constraints: localStorage para persistência, sem backend/login
- Nova Agent: not needed
- Completed: (updated during iterations)
- Current iteration: Build inicial completo
